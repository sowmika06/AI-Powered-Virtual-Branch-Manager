import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import Link from "next/link"

export default function ApplyPage() {
  return (
    <div className="container mx-auto px-4 py-12">
      <div className="max-w-3xl mx-auto">
        <h1 className="text-3xl font-bold mb-6">Apply for a Loan</h1>
        <Card>
          <CardContent className="p-6">
            <div className="space-y-6">
              <div>
                <h2 className="text-2xl font-semibold mb-4">Welcome to VidFin</h2>
                <p className="text-muted-foreground mb-4">
                  You're about to experience a new way of applying for a loan. Instead of filling out lengthy forms,
                  you'll have a video conversation with our AI Branch Manager who will guide you through the process.
                </p>
                <p className="text-muted-foreground mb-4">Here's what you'll need:</p>
                <ul className="list-disc pl-5 space-y-2 text-muted-foreground mb-6">
                  <li>A device with a camera and microphone</li>
                  <li>Your ID documents (Aadhaar, PAN card)</li>
                  <li>Proof of income (salary slips, bank statements)</li>
                  <li>About 10-15 minutes of your time</li>
                </ul>
              </div>

              <div className="flex flex-col space-y-4">
                <h3 className="text-lg font-medium">Available Loan Types:</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Link href="/apply/personal" className="w-full">
                    <Button variant="outline" className="w-full justify-start h-auto py-4 px-4">
                      <div className="flex flex-col items-start">
                        <span className="text-lg font-medium">Personal Loan</span>
                        <span className="text-sm text-muted-foreground">For your personal needs</span>
                      </div>
                    </Button>
                  </Link>
                  <Link href="/apply/home" className="w-full">
                    <Button variant="outline" className="w-full justify-start h-auto py-4 px-4">
                      <div className="flex flex-col items-start">
                        <span className="text-lg font-medium">Home Loan</span>
                        <span className="text-sm text-muted-foreground">For buying or renovating a home</span>
                      </div>
                    </Button>
                  </Link>
                  <Link href="/apply/business" className="w-full">
                    <Button variant="outline" className="w-full justify-start h-auto py-4 px-4">
                      <div className="flex flex-col items-start">
                        <span className="text-lg font-medium">Business Loan</span>
                        <span className="text-sm text-muted-foreground">For your business needs</span>
                      </div>
                    </Button>
                  </Link>
                  <Link href="/apply/education" className="w-full">
                    <Button variant="outline" className="w-full justify-start h-auto py-4 px-4">
                      <div className="flex flex-col items-start">
                        <span className="text-lg font-medium">Education Loan</span>
                        <span className="text-sm text-muted-foreground">For higher education</span>
                      </div>
                    </Button>
                  </Link>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

