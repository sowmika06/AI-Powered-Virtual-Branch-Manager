import type { Metadata } from "next"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { DashboardHeader } from "@/components/dashboard-header"
import { DashboardShell } from "@/components/dashboard-shell"

export const metadata: Metadata = {
  title: "Loan Decisions | LoanPal",
  description: "View your loan application decisions",
}

export default function DecisionsPage() {
  return (
    <DashboardShell>
      <DashboardHeader heading="Loan Decisions" text="View the status and decisions for your loan applications" />

      <div className="grid gap-6">
        <Card className="border-green-200">
          <CardHeader className="bg-green-50 border-b border-green-100">
            <div className="flex items-center justify-between">
              <CardTitle className="text-green-800">Personal Loan</CardTitle>
              <Badge className="bg-green-100 text-green-800 hover:bg-green-100">Approved</Badge>
            </div>
            <CardDescription className="text-green-700">
              Application #PL-2023-0042 • Submitted on 15 Mar 2023
            </CardDescription>
          </CardHeader>
          <CardContent className="p-6">
            <div className="space-y-6">
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
                <div>
                  <p className="text-sm font-medium mb-1">Loan Amount</p>
                  <p className="text-2xl font-bold">₹3,50,000</p>
                </div>
                <div>
                  <p className="text-sm font-medium mb-1">Interest Rate</p>
                  <p className="text-2xl font-bold">10.5% p.a.</p>
                </div>
                <div>
                  <p className="text-sm font-medium mb-1">Tenure</p>
                  <p className="text-2xl font-bold">36 months</p>
                </div>
                <div>
                  <p className="text-sm font-medium mb-1">EMI</p>
                  <p className="text-2xl font-bold">₹11,350</p>
                </div>
              </div>

              <div className="space-y-4">
                <h3 className="text-lg font-medium">Decision Details</h3>
                <div className="bg-green-50 border border-green-100 rounded-lg p-4">
                  <div className="flex items-start">
                    <div className="flex-shrink-0 mt-0.5">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="24"
                        height="24"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="h-5 w-5 text-green-600"
                      >
                        <path d="M20 6 9 17l-5-5" />
                      </svg>
                    </div>
                    <div className="ml-3">
                      <h4 className="text-sm font-medium text-green-800">
                        Congratulations! Your loan has been approved.
                      </h4>
                      <p className="mt-1 text-sm text-green-700">
                        Based on your profile, documents, and credit history, we are pleased to offer you a personal
                        loan of ₹3,50,000 at 10.5% interest rate for 36 months.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="h-5 w-5 text-green-600 mr-2"
                    >
                      <path d="M20 6 9 17l-5-5" />
                    </svg>
                    <span>Identity verification successful</span>
                  </div>
                  <div className="flex items-center">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="h-5 w-5 text-green-600 mr-2"
                    >
                      <path d="M20 6 9 17l-5-5" />
                    </svg>
                    <span>Income verification successful</span>
                  </div>
                  <div className="flex items-center">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="h-5 w-5 text-green-600 mr-2"
                    >
                      <path d="M20 6 9 17l-5-5" />
                    </svg>
                    <span>Credit score check successful</span>
                  </div>
                  <div className="flex items-center">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="h-5 w-5 text-green-600 mr-2"
                    >
                      <path d="M20 6 9 17l-5-5" />
                    </svg>
                    <span>Eligibility criteria met</span>
                  </div>
                </div>
              </div>

              <div className="flex flex-col space-y-2 sm:flex-row sm:space-y-0 sm:space-x-2">
                <Button className="flex-1">Accept Offer</Button>
                <Button variant="outline" className="flex-1">
                  View Details
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-red-200">
          <CardHeader className="bg-red-50 border-b border-red-100">
            <div className="flex items-center justify-between">
              <CardTitle className="text-red-800">Business Loan</CardTitle>
              <Badge className="bg-red-100 text-red-800 hover:bg-red-100">Rejected</Badge>
            </div>
            <CardDescription className="text-red-700">
              Application #BL-2023-0018 • Submitted on 10 Feb 2023
            </CardDescription>
          </CardHeader>
          <CardContent className="p-6">
            <div className="space-y-6">
              <div className="grid gap-4 md:grid-cols-2">
                <div>
                  <p className="text-sm font-medium mb-1">Requested Amount</p>
                  <p className="text-2xl font-bold">₹15,00,000</p>
                </div>
                <div>
                  <p className="text-sm font-medium mb-1">Requested Tenure</p>
                  <p className="text-2xl font-bold">60 months</p>
                </div>
              </div>

              <div className="space-y-4">
                <h3 className="text-lg font-medium">Decision Details</h3>
                <div className="bg-red-50 border border-red-100 rounded-lg p-4">
                  <div className="flex items-start">
                    <div className="flex-shrink-0 mt-0.5">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="24"
                        height="24"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="h-5 w-5 text-red-600"
                      >
                        <path d="M18 6 6 18" />
                        <path d="m6 6 12 12" />
                      </svg>
                    </div>
                    <div className="ml-3">
                      <h4 className="text-sm font-medium text-red-800">
                        We're sorry, your business loan application has been declined.
                      </h4>
                      <p className="mt-1 text-sm text-red-700">
                        Based on our assessment, we are unable to approve your business loan application at this time.
                        You may reapply after 3 months.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="h-5 w-5 text-green-600 mr-2"
                    >
                      <path d="M20 6 9 17l-5-5" />
                    </svg>
                    <span>Identity verification successful</span>
                  </div>
                  <div className="flex items-center">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="h-5 w-5 text-red-600 mr-2"
                    >
                      <path d="M18 6 6 18" />
                      <path d="m6 6 12 12" />
                    </svg>
                    <span>Business vintage less than required</span>
                  </div>
                  <div className="flex items-center">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="h-5 w-5 text-red-600 mr-2"
                    >
                      <path d="M18 6 6 18" />
                      <path d="m6 6 12 12" />
                    </svg>
                    <span>Insufficient business turnover</span>
                  </div>
                </div>
              </div>

              <Button variant="outline" className="w-full">
                View Details
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardShell>
  )
}

