import type { Metadata } from "next"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { DashboardHeader } from "@/components/dashboard-header"
import { DashboardShell } from "@/components/dashboard-shell"

export const metadata: Metadata = {
  title: "Eligibility | LoanPal",
  description: "Check your loan eligibility status",
}

export default function EligibilityPage() {
  return (
    <DashboardShell>
      <DashboardHeader heading="Loan Eligibility" text="Check your eligibility for different loan products" />

      <div className="grid gap-6">
        <Card className="border-green-200">
          <CardHeader className="bg-green-50 border-b border-green-100">
            <div className="flex items-center justify-between">
              <CardTitle className="text-green-800">Personal Loan</CardTitle>
              <Badge className="bg-green-100 text-green-800 hover:bg-green-100">Eligible</Badge>
            </div>
            <CardDescription className="text-green-700">Based on your profile and documents</CardDescription>
          </CardHeader>
          <CardContent className="p-6">
            <div className="space-y-6">
              <div className="grid gap-4 md:grid-cols-2">
                <div>
                  <p className="text-sm font-medium mb-1">Maximum Eligible Amount</p>
                  <p className="text-2xl font-bold text-green-700">₹5,00,000</p>
                </div>
                <div>
                  <p className="text-sm font-medium mb-1">Interest Rate</p>
                  <p className="text-2xl font-bold">10.5% p.a.</p>
                </div>
                <div>
                  <p className="text-sm font-medium mb-1">Maximum Tenure</p>
                  <p className="text-2xl font-bold">60 months</p>
                </div>
                <div>
                  <p className="text-sm font-medium mb-1">Processing Fee</p>
                  <p className="text-2xl font-bold">1.5%</p>
                </div>
              </div>

              <div className="space-y-4">
                <h3 className="text-lg font-medium">Eligibility Factors</h3>

                <div className="space-y-3">
                  <div className="space-y-1">
                    <div className="flex justify-between text-sm">
                      <span>Credit Score</span>
                      <span className="font-medium">Excellent (780)</span>
                    </div>
                    <Progress value={95} className="h-2" />
                  </div>

                  <div className="space-y-1">
                    <div className="flex justify-between text-sm">
                      <span>Income Stability</span>
                      <span className="font-medium">Good</span>
                    </div>
                    <Progress value={80} className="h-2" />
                  </div>

                  <div className="space-y-1">
                    <div className="flex justify-between text-sm">
                      <span>Existing Debt</span>
                      <span className="font-medium">Low</span>
                    </div>
                    <Progress value={85} className="h-2" />
                  </div>

                  <div className="space-y-1">
                    <div className="flex justify-between text-sm">
                      <span>Employment History</span>
                      <span className="font-medium">Excellent</span>
                    </div>
                    <Progress value={90} className="h-2" />
                  </div>
                </div>
              </div>

              <Button className="w-full">Apply Now</Button>
            </div>
          </CardContent>
        </Card>

        <div className="grid gap-6 md:grid-cols-2">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Home Loan</CardTitle>
                <Badge variant="outline">Check Eligibility</Badge>
              </div>
              <CardDescription>For buying or renovating a home</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm font-medium mb-1">Interest Rate</p>
                    <p className="text-lg font-semibold">8.5% p.a.</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium mb-1">Max Tenure</p>
                    <p className="text-lg font-semibold">30 years</p>
                  </div>
                </div>
                <Button variant="outline" className="w-full">
                  Check Eligibility
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Education Loan</CardTitle>
                <Badge variant="outline">Check Eligibility</Badge>
              </div>
              <CardDescription>For higher education expenses</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm font-medium mb-1">Interest Rate</p>
                    <p className="text-lg font-semibold">9.0% p.a.</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium mb-1">Max Tenure</p>
                    <p className="text-lg font-semibold">15 years</p>
                  </div>
                </div>
                <Button variant="outline" className="w-full">
                  Check Eligibility
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </DashboardShell>
  )
}

