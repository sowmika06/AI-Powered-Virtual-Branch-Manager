import type { Metadata } from "next"
import Image from "next/image"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { DashboardHeader } from "@/components/dashboard-header"
import { DashboardShell } from "@/components/dashboard-shell"

export const metadata: Metadata = {
  title: "Video Calls | LoanPal",
  description: "View your video call history with our AI banking assistant",
}

export default function VideoCallsPage() {
  return (
    <DashboardShell>
      <DashboardHeader heading="Video Calls" text="Your video interactions with our AI banking assistant" />

      <div className="grid gap-6">
        <Card className="overflow-hidden">
          <div className="relative aspect-video">
            <Image
              src="/placeholder.svg?height=500&width=900"
              alt="AI Banking Assistant"
              fill
              className="object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex flex-col justify-end p-6">
              <div className="flex items-center space-x-4 mb-4">
                <div className="h-12 w-12 rounded-full bg-primary flex items-center justify-center">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="h-6 w-6 text-white"
                  >
                    <path d="M14.5 4h-5L7 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3l-2.5-3z" />
                    <circle cx="12" cy="13" r="3" />
                  </svg>
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-white">Start a New Video Call</h3>
                  <p className="text-white/80">Connect with our AI banking assistant</p>
                </div>
              </div>
              <Button size="lg" className="w-full md:w-auto">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="h-5 w-5 mr-2"
                >
                  <path d="m22 8-6 4 6 4V8Z" />
                  <rect width="14" height="12" x="2" y="6" rx="2" ry="2" />
                </svg>
                Start Video Call
              </Button>
            </div>
          </div>
        </Card>

        <h2 className="text-xl font-semibold mt-6 mb-4">Recent Video Calls</h2>

        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          <Card>
            <CardHeader className="pb-2">
              <div className="flex justify-between items-start">
                <CardTitle>Personal Loan Discussion</CardTitle>
                <Badge>2 days ago</Badge>
              </div>
              <CardDescription>18 Mar 2023, 10:30 AM</CardDescription>
            </CardHeader>
            <CardContent className="pb-2">
              <div className="relative aspect-video rounded-md overflow-hidden mb-3">
                <Image
                  src="/placeholder.svg?height=200&width=350"
                  alt="Video Call Thumbnail"
                  fill
                  className="object-cover"
                />
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="h-12 w-12 rounded-full bg-black/50 flex items-center justify-center">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="h-6 w-6 text-white"
                    >
                      <polygon points="5 3 19 12 5 21 5 3" />
                    </svg>
                  </div>
                </div>
              </div>
              <p className="text-sm text-muted-foreground">
                Discussion about personal loan eligibility and document requirements.
              </p>
            </CardContent>
            <CardFooter>
              <Button variant="outline" className="w-full">
                View Recording
              </Button>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <div className="flex justify-between items-start">
                <CardTitle>Document Verification</CardTitle>
                <Badge>5 days ago</Badge>
              </div>
              <CardDescription>15 Mar 2023, 2:15 PM</CardDescription>
            </CardHeader>
            <CardContent className="pb-2">
              <div className="relative aspect-video rounded-md overflow-hidden mb-3">
                <Image
                  src="/placeholder.svg?height=200&width=350"
                  alt="Video Call Thumbnail"
                  fill
                  className="object-cover"
                />
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="h-12 w-12 rounded-full bg-black/50 flex items-center justify-center">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="h-6 w-6 text-white"
                    >
                      <polygon points="5 3 19 12 5 21 5 3" />
                    </svg>
                  </div>
                </div>
              </div>
              <p className="text-sm text-muted-foreground">
                Verification of identity documents and address proof for loan application.
              </p>
            </CardContent>
            <CardFooter>
              <Button variant="outline" className="w-full">
                View Recording
              </Button>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <div className="flex justify-between items-start">
                <CardTitle>Initial Consultation</CardTitle>
                <Badge>1 week ago</Badge>
              </div>
              <CardDescription>12 Mar 2023, 11:00 AM</CardDescription>
            </CardHeader>
            <CardContent className="pb-2">
              <div className="relative aspect-video rounded-md overflow-hidden mb-3">
                <Image
                  src="/placeholder.svg?height=200&width=350"
                  alt="Video Call Thumbnail"
                  fill
                  className="object-cover"
                />
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="h-12 w-12 rounded-full bg-black/50 flex items-center justify-center">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="h-6 w-6 text-white"
                    >
                      <polygon points="5 3 19 12 5 21 5 3" />
                    </svg>
                  </div>
                </div>
              </div>
              <p className="text-sm text-muted-foreground">
                Initial discussion about loan options and financial needs assessment.
              </p>
            </CardContent>
            <CardFooter>
              <Button variant="outline" className="w-full">
                View Recording
              </Button>
            </CardFooter>
          </Card>
        </div>
      </div>
    </DashboardShell>
  )
}

